#include <stdlib.h>
#include <stdio.h>
#include "hash.h"

HASH_TABLE *hash_table_create(){
    HASH_TABLE *hash_table = malloc(sizeof(HASH_TABLE));
    if (hash_table != NULL){
        hash_table->data = NULL;
    }
    return hash_table;
}

boolean hash_table_destroy(HASH_TABLE **hash_table, int key){
    if (hash_table != NULL && *hash_table != NULL){
        matrix_destroy((*hash_table)->data, key);
        free(*hash_table);
        (*hash_table) = NULL;
        return TRUE;
    }
    return FALSE;
}

boolean hash_table_preparation(HASH_TABLE *hash_table, int key){
	if (hash_table != NULL){
		hash_table->data = (TYPE **) malloc(sizeof(TYPE *) * (key));
		for(int i = EMPTY; i < key; i++)
			hash_table->data[i] = calloc(UNITY, sizeof(TYPE));
		return TRUE;
	}
	return FALSE;
}

boolean hash_table_fill(HASH_TABLE *hash_table, char *filename, int key){
	FILE *fp = fopen(filename, "r");
	int index = EMPTY;
	TYPE element = EMPTY;
	if (fp != NULL){
		if (hash_table != NULL){
			hash_table_preparation(hash_table, key);
			while(!feof(fp)){
				fscanf(fp, "%d", &element);
				index = (element % key);
				hash_table->data[index][EMPTY]++;
				hash_table->data[index] = realloc(hash_table->data[index], sizeof(TYPE) * (hash_table->data[index][EMPTY] + UNITY));
				hash_table->data[index][hash_table->data[index][EMPTY]] = element;
			}
			fclose(fp);
			return TRUE;
		}
	}
	fclose(fp);
	return FALSE;
}

boolean hash_table_output(HASH_TABLE *hash_table, char *filename, int key){
	if (hash_table != NULL){
		FILE *fp = fopen(filename, "w");
		if (fp != NULL){
			for(int i = EMPTY; i < key; i++){
				fprintf(fp, "(%d) %d.", hash_table->data[i][EMPTY], i);
				for(int j = UNITY; j <= hash_table->data[i][EMPTY]; j++)
					fprintf(fp, " %d", hash_table->data[i][j]);
				fprintf(fp, "\n");
			}
			fclose(fp);
			return TRUE;
		}
	}
	return FALSE;
}