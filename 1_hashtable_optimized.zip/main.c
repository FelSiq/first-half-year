#include <stdlib.h>
#include <stdio.h>
#include "hash.h"

#define NUM_ARGS 3

int main(int argc, char **argv){
	HASH_TABLE *hash_table = hash_table_create();
	char *filename_input = NULL, *filename_output = NULL;
	int key;
	if (hash_table != NULL){
		printf("Successfuly created hash structure...\n");
		if (argc < NUM_ARGS){
			printf("Insert the filename of the elements:\n");
			filename_input = get_string();
			printf("Insert the name of new output file:\n");
			filename_output = get_string();
		}else{
			filename_input  = argv[1];
			filename_output = argv[2];
		}

		if (filename_input != NULL && filename_output != NULL){
			if (argc < NUM_ARGS){
				printf("Please enter a valid key:\n");
				key = get_key();
			}else key = atoi(argv[3]);

			if (key > EMPTY){
				printf("Key is valid, starting to hash elements...\n");
				if(hash_table_fill(hash_table, filename_input, key)){
					printf("Success! Generating a output file now...\n");
					if(hash_table_output(hash_table, filename_output, key))
						printf("Successffuly generated output file, program now is exiting...\n");
				}
			}
			if (argc < NUM_ARGS){
				printf("Degenerating filenames...\n");
				free(filename_input);
				free(filename_output);
			}
		}
		if(hash_table_destroy(&hash_table, key))
			printf("Successffuly deallocated hash structure...\n");
	}
	printf("Cya my friend!\n");
	return 0;
}