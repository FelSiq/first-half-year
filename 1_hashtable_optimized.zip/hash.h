#ifndef _HASH_TABLE_
#define _HASH_TABLE_

#include "utils.h"

typedef struct{
    TYPE **data;
} HASH_TABLE;

HASH_TABLE *hash_table_create();
boolean hash_table_destroy(HASH_TABLE **, int);
boolean hash_table_preparation(HASH_TABLE *, int);
boolean hash_table_fill(HASH_TABLE *, char *, int);
boolean hash_table_output(HASH_TABLE *, char *, int);

#endif