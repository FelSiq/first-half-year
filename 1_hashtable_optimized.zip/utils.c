#include <stdlib.h>
#include <stdio.h>
#include "utils.h"

int get_key(){
	int key = INVALID;
	do{
		scanf("%d", &key);
		getchar();
		if (key <= EMPTY)
			printf("ERROR: Invalid key, try again:\n");
	}while(key <= EMPTY);
	return key;
}

char *get_string(){
	char *string = NULL, c = EMPTY;
	int counter = EMPTY;
	while(c != ENTER){
		c = fgetc(stdin);
		string = (char *) realloc(string, sizeof(char) * (counter + UNITY));
		string[counter++] = c;
	}
	string[counter - UNITY] = '\0';
	return string;
}

boolean matrix_destroy(TYPE **matrix, int row){
	if (matrix != NULL){
		for(int i = EMPTY; i < row; i++)
			if (matrix[i] != NULL)
				free(matrix[i]);
		free(matrix);
		return TRUE;
	}
	return FALSE;
}