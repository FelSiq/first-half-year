#ifndef _UTILS_LIB_
#define _UTILS_LIB_

typedef int TYPE;

typedef enum{
    FALSE,
    TRUE
} boolean;

enum{
    INVALID = -1,
    EMPTY,
    UNITY,
    ENTER = 10
};

int get_key();
char *get_string();
boolean matrix_destroy(TYPE **, int);

#endif